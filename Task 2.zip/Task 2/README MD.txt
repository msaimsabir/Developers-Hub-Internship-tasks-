# Task 2: Stock Price Prediction (Short-Term)

## 🎯 Objective
Use historical stock data to predict the **next day's closing price** using today's market features:
- Open
- High
- Low
- Volume

---

## 📦 Dataset
- **Source**: [Yahoo Finance](https://finance.yahoo.com)
- **Ticker**: AAPL (Apple Inc.)
- **Period**: Jan 2022 – Dec 2024
- **Fetched via**: `yfinance` Python package

---

## 🛠️ Tools & Libraries
- `pandas`, `matplotlib`, `seaborn`
- `yfinance` for stock data
- `scikit-learn` for modeling and evaluation

---

## ⚙️ Features Used
- `Open`, `High`, `Low`, `Volume` → from **today**
- `Close` → target (for **next day**)

---

## 📈 Models Applied

### 1. Random Forest Regressor
- Simple ensemble model
- **MSE**: 1105.00  
- **MAE**: 30.30  
- **Observation**: Performed poorly. Predictions were nearly flat, indicating the model struggled to generalize from limited input features.

### 2. Linear Regression ✅ (Chosen)
- Simple baseline regression
- **MSE**: 14.19  
- **MAE**: 3.06  
- **Observation**: Outperformed Random Forest significantly. Demonstrated better alignment with real market data using the same features.

---

## 🖼️ Visual Output
*(Include screenshots of actual vs predicted graphs here if desired)*

---

## ✅ Key Insights
- Feature-to-target alignment was critical (predicting tomorrow’s close using today’s data).
- Complex models like Random Forest can underperform with limited sequential context.
- Simpler models like Linear Regression can be more effective for linear or stationary trends.

---

## 🧠 Learnings
- Learned to properly align time-series data for prediction.
- Understood model behavior differences between tree-based and linear regressors.
- Gained experience in evaluating regression models using MSE and MAE.

---

## 📁 Files Included
- `Task2_Stock_Price_Prediction_Fixed.ipynb` – Random Forest version
- `Task2_Stock_Price_Prediction_LinearRegression.ipynb` – Final chosen model
- `README.md`
- `NOTES.md` *(Optional but recommended)*
