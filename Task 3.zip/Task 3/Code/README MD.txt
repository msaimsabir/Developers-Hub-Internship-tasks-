# Task 3: Heart Disease Prediction (Binary Classification)

## 🎯 Objective
Predict the presence or absence of heart disease in patients using clinical data. The task is framed as a binary classification problem based on historical patient information.

---

## 📦 Dataset
- **Source**: UCI Heart Disease Dataset (manually provided)
- **Description**: Contains patient health data such as age, sex, blood pressure, cholesterol levels, and more.
- **Target**: `num` (converted to `target`) → `0` = No Heart Disease, `1` = Has Heart Disease

---

## 🛠️ Tools & Libraries
- `pandas`, `matplotlib`, `seaborn`
- `scikit-learn` for modeling, preprocessing, and evaluation

---

## ⚙️ Features Used
- **Numerical**: `age`, `trestbps`, `chol`, `thalch`, `oldpeak`, `ca`
- **Categorical (one-hot encoded if available)**: `cp`, `restecg`, `slope`, `thal`
- **Binary**: `sex`, `fbs`, `exang`

---

## ⚙️ Preprocessing Summary
- Converted `'Male'/'Female'` to binary values in `sex`
- Mapped `'TRUE'/'FALSE'` to `1/0` for boolean columns
- Handled missing values with `.fillna(0)` after encoding
- Applied one-hot encoding **only if** certain categorical columns were present
- Created `target` column by converting `num > 0` to `1`, otherwise `0`

---

## 📈 Models Applied

### 1. Logistic Regression ✅ (Chosen)
- Interpretable, linear model
- **Accuracy**: ~80.98%
- **AUC Score**: ~0.89
- **Observation**: Performed well with balanced precision and recall; smooth ROC curve

### 2. Decision Tree
- Non-linear baseline classifier
- **Accuracy**: ~77.72%
- **Observation**: Slightly lower performance, more prone to overfitting with default settings

---

## 🖼️ Visual Output
- Confusion Matrix showing TP, FP, FN, TN values
- ROC Curve for Logistic Regression with AUC annotation

---

## ✅ Key Insights
- Logistic Regression outperformed Decision Tree with cleaner, more generalizable predictions.
- Handling mapping and missing values **after** encoding was critical for model success.
- AUC Score of 0.89 indicates strong discriminatory power for heart disease risk.

---

## 🧠 Learnings
- Reinforced importance of proper binary classification framing
- Understood the need for conditional encoding and safe preprocessing
- Learned to debug common data issues (e.g. NaNs after mapping)
- Practiced evaluating models using multiple metrics, not just accuracy

---

## 📁 Files Included
- `Task3_Heart_Disease_Prediction_Fixed_Final.ipynb` – Full Jupyter Notebook
- `TASK3_README.md` – This file
- `TASK3_NOTES.md` – Internal developer notes with troubleshooting and model reasoning

---
