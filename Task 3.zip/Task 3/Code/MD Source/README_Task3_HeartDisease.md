# 🫀 Task 3: Heart Disease Prediction

## 📌 Overview
This task involves predicting the presence of heart disease using a structured dataset from the UCI Heart Disease dataset. We applied supervised machine learning techniques, mainly logistic regression and decision tree classifiers.

## 📁 Dataset
- Dataset: `heart_disease_uci.csv`
- Rows: 270+ samples (after cleaning)
- Columns include: `age`, `sex`, `chol`, `fbs`, `exang`, `ca`, etc.

## 🧹 Preprocessing
- Dropped unnecessary columns (`id`, `dataset`)
- Converted `TRUE`/`FALSE` strings to binary `1/0`
- Converted `sex` to binary
- Handled missing values by filling them with `0`
- Created binary target: `target` from `num`
- One-hot encoded categorical features like `cp`, `thal`, `slope`, if present

## ⚙️ Models Used
- **Logistic Regression**
- **Decision Tree Classifier**

## 📊 Evaluation Metrics
- **Accuracy**
  - Logistic Regression: ~81%
  - Decision Tree: ~78%
- **ROC AUC Score**: ~0.89 (Logistic Regression)
- **Confusion Matrix**:
  - True Positives: 88
  - False Positives: 14
  - False Negatives: 21
  - True Negatives: 61

## ✅ Conclusion
- Logistic Regression outperformed the Decision Tree.
- AUC score suggests a strong ability to distinguish between classes.
- The notebook is ready for extension, tuning, or deployment demo.

## 📂 Files
- `Task3_Heart_Disease_Prediction_Fixed_Final.ipynb` – Main Jupyter Notebook
- `NOTES_Task3_HeartDisease.md` – Notes and observations

