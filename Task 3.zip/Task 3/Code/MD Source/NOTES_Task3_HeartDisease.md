# 🧾 Notes for Task 3: Heart Disease Prediction

## 🧠 Key Takeaways
- Encoding booleans as 'TRUE'/'FALSE' needed careful `.map()` conversion.
- Filling missing values after `.map()` avoids NaNs from unmatched categories.
- One-hot encoding only applied to columns present in the dataset.
- The 'num' column was converted to binary for classification (`target`).

## ⚠️ Challenges
- Missing values from unexpected mappings (e.g. unrecognized 'sex' strings)
- Columns like `cp`, `thal`, `slope` not always available
- `LogisticRegression` does not tolerate NaNs → forced reliable `fillna(0)`

## 📊 Model Insights
- Logistic Regression provided better AUC and accuracy compared to Decision Tree.
- Decision Tree may overfit without pruning or depth control.
- Final accuracy and AUC are good for a baseline model.

## 🔍 Suggestions for Improvement
- Add cross-validation (e.g., `StratifiedKFold`)
- Try ensemble models like RandomForest or XGBoost
- Use feature importance and SHAP values for interpretability
- Tune hyperparameters with `GridSearchCV`

