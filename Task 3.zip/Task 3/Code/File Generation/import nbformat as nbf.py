import nbformat as nbf

# File path for your structured notebook
notebook_path = "Task3_Heart_Disease_Prediction.ipynb"

# Create a new notebook
nb = nbf.v4.new_notebook()

# List of cells (markdown + code)
cells = []

# Title & Objective
cells.append(nbf.v4.new_markdown_cell("""# Task 3: Heart Disease Prediction

### 🎯 Objective
Predict whether a patient is at risk of heart disease using health-related features.
This notebook includes:
- Data cleaning & preprocessing
- Feature engineering (binary and one-hot encoding)
- Feature scaling
- Model training using Logistic Regression and Decision Tree
- Model evaluation using Accuracy, Confusion Matrix, and ROC Curve
"""))

# Imports
cells.append(nbf.v4.new_code_cell("""import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LogisticRegression
from sklearn.tree import DecisionTreeClassifier
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import accuracy_score, confusion_matrix, roc_auc_score, roc_curve

%matplotlib inline"""))

# Load dataset
cells.append(nbf.v4.new_markdown_cell("## 📥 Load Dataset"))
cells.append(nbf.v4.new_code_cell("""df = pd.read_csv('heart.csv')
df.head()"""))

# Data cleaning
cells.append(nbf.v4.new_markdown_cell("## 🧹 Data Cleaning and Preprocessing"))
cells.append(nbf.v4.new_code_cell("""# Drop unused columns if present
cols_to_drop = ['id', 'dataset']
df.drop(columns=[col for col in cols_to_drop if col in df.columns], inplace=True)
df = df.dropna()

# Convert booleans
df.replace({'TRUE': 1, 'FALSE': 0}, inplace=True)

# Convert 'sex' to binary
df['sex'] = df['sex'].map({'Male': 1, 'Female': 0})

# Convert 'num' to binary target
df['target'] = df['num'].apply(lambda x: 1 if x > 0 else 0)
df.drop(columns=['num'], inplace=True)"""))

# One-hot encoding
cells.append(nbf.v4.new_markdown_cell("## 🔢 One-Hot Encoding"))
cells.append(nbf.v4.new_code_cell("""categorical_cols = ['cp', 'restecg', 'slope', 'thal']
df = pd.get_dummies(df, columns=categorical_cols, drop_first=True)
df.head()"""))

# Train-test split
cells.append(nbf.v4.new_markdown_cell("## ✂️ Train-Test Split"))
cells.append(nbf.v4.new_code_cell("""X = df.drop('target', axis=1)
y = df['target']

X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)"""))

# Feature scaling
cells.append(nbf.v4.new_markdown_cell("## ⚖️ Feature Scaling"))
cells.append(nbf.v4.new_code_cell("""scaler = StandardScaler()
X_train_scaled = scaler.fit_transform(X_train)
X_test_scaled = scaler.transform(X_test)"""))

# Logistic Regression
cells.append(nbf.v4.new_markdown_cell("## 🤖 Logistic Regression"))
cells.append(nbf.v4.new_code_cell("""log_model = LogisticRegression(max_iter=1000)
log_model.fit(X_train_scaled, y_train)
y_pred_log = log_model.predict(X_test_scaled)"""))

# Decision Tree
cells.append(nbf.v4.new_markdown_cell("## 🌳 Decision Tree"))
cells.append(nbf.v4.new_code_cell("""tree_model = DecisionTreeClassifier()
tree_model.fit(X_train, y_train)
y_pred_tree = tree_model.predict(X_test)"""))

# Evaluation
cells.append(nbf.v4.new_markdown_cell("## 📊 Evaluation"))
cells.append(nbf.v4.new_code_cell("""print('Logistic Regression Accuracy:', accuracy_score(y_test, y_pred_log))
print('Decision Tree Accuracy:', accuracy_score(y_test, y_pred_tree))"""))

# Confusion Matrix
cells.append(nbf.v4.new_markdown_cell("## 🧱 Confusion Matrix"))
cells.append(nbf.v4.new_code_cell("""sns.heatmap(confusion_matrix(y_test, y_pred_log), annot=True, fmt='d', cmap='Blues')
plt.title('Logistic Regression - Confusion Matrix')
plt.xlabel('Predicted')
plt.ylabel('Actual')
plt.show()"""))

# ROC Curve
cells.append(nbf.v4.new_markdown_cell("## 📈 ROC Curve"))
cells.append(nbf.v4.new_code_cell("""y_prob_log = log_model.predict_proba(X_test_scaled)[:, 1]
fpr, tpr, _ = roc_curve(y_test, y_prob_log)
roc_auc = roc_auc_score(y_test, y_prob_log)

plt.figure(figsize=(8, 6))
plt.plot(fpr, tpr, label=f'Logistic Regression (AUC = {roc_auc:.2f})')
plt.plot([0, 1], [0, 1], 'k--')
plt.xlabel('False Positive Rate')
plt.ylabel('True Positive Rate')
plt.title('ROC Curve')
plt.legend()
plt.grid(True)
plt.show()"""))

# Conclusion
cells.append(nbf.v4.new_markdown_cell("""## ✅ Conclusion
- Cleaned and preprocessed custom dataset.
- Converted categorical and boolean values properly.
- Scaled features to resolve convergence issues.
- Trained and evaluated Logistic Regression and Decision Tree models.
- Used Accuracy, Confusion Matrix, and ROC Curve for evaluation.
"""))

# Assign cells and save notebook
nb['cells'] = cells
with open(notebook_path, 'w', encoding='utf-8') as f:
    nbf.write(nb, f)

print(f"Notebook generated and saved as: {notebook_path}")
