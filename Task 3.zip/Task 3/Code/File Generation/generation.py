import nbformat as nbf

# Define Python code you want in the notebook
code = '''
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LogisticRegression
from sklearn.tree import DecisionTreeClassifier
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import accuracy_score, confusion_matrix, roc_auc_score, roc_curve
%matplotlib inline

df = pd.read_csv("heart.csv")
# [Insert rest of your Python code from earlier here...]
'''

# Create a new Jupyter notebook object
nb = nbf.v4.new_notebook()

# Add your code as a code cell
nb['cells'] = [nbf.v4.new_code_cell(code)]

# Save the notebook to a file
with open("Task3_Heart_Disease_Prediction.ipynb", "w") as f:
    nbf.write(nb, f)
