from nbformat import v4 as nbf

# Output path
output_path = "Task4_HealthChatbot_HuggingFace.ipynb"

# Notebook content
cells = []

# Markdown: Title and disclaimer
cells.append(nbf.new_markdown_cell("""# 🩺 Task 4: General Health Chatbot (Hugging Face Version)

This notebook uses a free and open-source LLM from Hugging Face to simulate a general health assistant chatbot.

---

**⚠️ Disclaimer:**  
This chatbot is for **educational use only** and does **not provide real medical advice**.
"""))

# Code: install + imports
cells.append(nbf.new_code_cell("""# 🔧 Install required packages (first time only)
# !pip install transformers torch accelerate --quiet

from transformers import pipeline
import re
"""))

# Code: load model
cells.append(nbf.new_code_cell("""# 🔄 Load model
chatbot = pipeline("text-generation", model="mistralai/Mistral-7B-Instruct", device_map="auto", max_new_tokens=200)
"""))

# Code: system prompt
cells.append(nbf.new_code_cell("""# 🧠 Assistant system prompt
SYSTEM_PROMPT = (
    "You are a friendly and cautious medical assistant. "
    "Answer general health-related questions clearly, but do not give any diagnosis or treatment. "
    "If a question could be dangerous, advise the user to consult a real doctor."
)
"""))

# Code: safety filter
cells.append(nbf.new_code_cell("""# 🚫 Block risky questions
def is_safe_query(query):
    forbidden_keywords = ['diagnose', 'diagnosis', 'prescribe', 'prescription', 'emergency', 'treat', 'treatment']
    return not any(word in query.lower() for word in forbidden_keywords)
"""))

# Code: chat function
cells.append(nbf.new_code_cell("""# 💬 Response generator
def ask_healthbot(query):
    if not is_safe_query(query):
        return "⚠️ Sorry, I can't assist with diagnosis or treatment. Please consult a medical professional."
    
    full_prompt = SYSTEM_PROMPT + "\\nUser: " + query + "\\nAssistant:"
    response = chatbot(full_prompt)[0]["generated_text"]
    return response.split("Assistant:")[-1].strip()
"""))

# Code: sample questions
cells.append(nbf.new_code_cell("""# 🧪 Example queries
sample_questions = [
    "What causes a sore throat?",
    "Is paracetamol safe for children?",
    "Can you diagnose chest pain?"  # blocked
]

for q in sample_questions:
    print(f"🧑‍💬 {q}")
    print(f"🤖 {ask_healthbot(q)}\\n")
"""))

# Code: optional chat
cells.append(nbf.new_code_cell("""# 🔁 Optional live chat
# Uncomment below to use

# print("💬 Ask a question (type 'exit' to stop):")
# while True:
#     user_input = input("You: ")
#     if user_input.lower() == 'exit':
#         print("👋 Goodbye!")
#         break
#     print("🤖", ask_healthbot(user_input))
"""))

# Markdown: summary
cells.append(nbf.new_markdown_cell("""---

## ✅ Summary

- Free, open-source chatbot using Hugging Face
- Safety filters added to avoid risky medical replies
- No API key or account required
- Ready for Task 4 submission!
"""))

# Build notebook
nb = nbf.new_notebook(cells=cells)

# Save it
with open(output_path, "w", encoding="utf-8") as f:
    f.write(nbf.writes(nb))

print(f"✅ Notebook generated: {output_path}")
