# Task 4: General Health Chatbot (LLM-Based)

## 🎯 Objective
Design a chatbot that can answer general health-related queries using a large language model (LLM), while ensuring responses remain safe, factual, and non-diagnostic. The chatbot should serve as an educational assistant — not a medical authority.

---

## 📦 Dataset
- **Source**: No dataset required; user queries serve as dynamic input.
- **Description**: Input is natural language questions related to health, processed and responded to via LLM.
- **Examples**:
  - `"What causes a sore throat?"`
  - `"Is paracetamol safe for children?"`
  - `"Can you diagnose chest pain?"` (blocked safely)

---

## 🛠️ Tools & Libraries
- `transformers` – for model inference using Hugging Face
- `huggingface_hub` – for authentication and access control
- `torch`, `accelerate` – model backend
- Python + Jupyter Notebook (Colab environment)

---

## ⚙️ Prompt Strategy
- A static **system prompt** was provided to the model:
  > "You are a friendly and cautious medical assistant. You offer general health education and never provide diagnoses or treatments."

- A keyword-based **safety filter** was added to intercept risky queries before model invocation:
  - Blocked terms included: `diagnose`, `prescribe`, `treat`, `emergency`, `overdose`, etc.
  - If unsafe, the bot replies with:
    > ⚠️ Sorry, I can't assist with diagnosis or treatment. Please consult a medical professional.

---

## 💬 Sample Query Results

```text
🧑‍💬 What causes a sore throat?
🤖 There are several home remedies that can help alleviate the discomfort...

🧑‍💬 Is paracetamol safe for children?
🤖 Paracetamol is generally safe when dosed appropriately...

🧑‍💬 Can you diagnose chest pain?
🤖 ⚠️ Sorry, I can't assist with diagnosis or treatment.


## ⚙️ Model Configuration
- **Model**: `mistralai/Mistral-7B-Instruct` (instruction-tuned LLM)
- **Access**: Requires Hugging Face token with gated model access enabled
- **Inference Method**: `pipeline("text-generation", model=...)`
- **Fallback Option**: Models like `falcon-7b-instruct` can be used without token for lighter deployment

---

## ✅ Key Insights
- Prompt tuning + keyword filtering created reliable and safe behavior
- The model successfully avoided sensitive or inappropriate replies
- Task demonstrates responsible AI usage in educational settings

---

## ❌ Challenges Faced
- 403 and 401 errors due to token permissions → fixed via Hugging Face dashboard
- Import issues with latest `transformers` version → resolved using `transformers==4.38.2`
- Slow response time (~2 minutes/query) on free Colab runtime

---

## 🧠 Learnings
- Practiced integrating LLMs via Hugging Face pipelines
- Learned how to apply prompt engineering for behavioral control
- Understood importance of output filtering in health-related applications
- Gained experience with gated models and authentication mechanisms

---

## 📁 Files Included
- `Task4_HealthChatbot.ipynb` – Main notebook with chatbot code and prompt logic
- `TASK4_README.md` – This file
- `TASK4_NOTES.md` – Developer notes, observations, and improvement areas

---

## 🚫 Disclaimer
This chatbot is for **educational purposes only**.  
It does **not** provide medical advice, diagnosis, or treatment.  
Always consult a licensed healthcare professional for real-world health concerns.
