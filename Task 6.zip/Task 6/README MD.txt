# Task 6: House Price Prediction (Regression Modeling)

## 🎯 Objective
Predict house prices using various property attributes like square footage, number of bedrooms, bathrooms, and location. The goal is to build and evaluate regression models that can generalize well on unseen data.

---

## 📦 Dataset
- **Source**: House Price Prediction Dataset (from Kaggle, provided manually)
- **Description**: Contains rows of real estate listings with features such as:
  - `SquareFeet`, `Bedrooms`, `Bathrooms`, `Garage`, `Area`, `Condition`, `Location`, and `Price`
- **Target**: `Price` (numeric value in dollars)

---

## 🛠️ Tools & Libraries
- `pandas`, `numpy`, `seaborn`, `matplotlib` – for data handling and visualization
- `scikit-learn` – for model training and evaluation
- Python + Jupyter Notebook (local or Colab environment)

---

## ⚙️ Preprocessing Summary
- Dropped rows with missing values (`df.dropna()`).
- Applied one-hot encoding via `pd.get_dummies()` for categorical columns (`Location`, `Condition`, etc.).
- Verified all features were numerical before training.

---

## ⚙️ Models Applied

### 1. Linear Regression ✅ (Final Choice)
- **Type**: Simple, interpretable linear model
- **MAE**: ~$242,867  
- **RMSE**: ~$279,785  
- **Outcome**: Best-performing model based on error metrics; predictions were consistent and smooth.

### 2. Gradient Boosting Regressor
- **Type**: Ensemble learning model with boosting
- **MAE**: ~$252,529  
- **RMSE**: ~$296,985  
- **Outcome**: Slightly underperformed; predictions had greater variance but lower accuracy.

---

## 📈 Visual Output

- Scatter plots for both models showed that most predictions were clustered between \$450k–\$600k.
- Limited spread in predictions suggests model underfitting or linear trends in the dataset.

---

## ✅ Key Insights
- Linear Regression surprisingly outperformed Gradient Boosting due to the linear nature of features and clean data.
- Feature encoding was critical to prevent `ValueError` during model training.
- Evaluation metrics (MAE, RMSE) guided clear model selection.

---

## 🧠 Learnings
- Gained hands-on experience with both linear and ensemble regression techniques.
- Understood the importance of preprocessing and encoding categorical data properly.
- Learned how to compare model performance using visualizations and error metrics.

---

## 📁 Files Included
- `Task6_House_Price_Prediction_LinearRegression.ipynb` – Linear regression implementation ✅
- `Task6_House_Price_Prediction_GradientBoosting.ipynb` – Gradient boosting (for experimentation)
- `TASK6_README.md` – This file
- `TASK6_NOTES.md` – Developer notes and observations

---

## 🚀 Future Enhancements
- Add feature scaling and log transformation for `Price`
- Try XGBoost or LightGBM for improved ensemble performance
- Add advanced feature engineering (e.g., price per square foot, location tiering)
- Incorporate cross-validation for more robust evaluation

---
