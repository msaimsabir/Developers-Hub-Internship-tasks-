import nbformat
from nbformat.v4 import new_notebook, new_code_cell, new_markdown_cell

nb = new_notebook()

cells = [
    new_markdown_cell("# 🏡 Task 6: House Price Prediction\nPredict house prices based on features like area, bedrooms, and location using regression models."),

    new_code_cell("""\
# 📦 Imports
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns

from sklearn.model_selection import train_test_split
from sklearn.linear_model import LinearRegression
from sklearn.metrics import mean_absolute_error, mean_squared_error
"""),

    new_code_cell("""\
# 🔍 Load Data
df = pd.read_csv('House Price Prediction Dataset.csv')
print("✅ Dataset Loaded")

# 🔎 Preview
print("First few rows:")
print(df.head())
print("\\n📊 Data Info:")
print(df.info())
"""),

    new_code_cell("""\
# 🧹 Handle Missing Values
print("\\n❓ Missing Values:")
print(df.isnull().sum())

# Drop missing rows
df = df.dropna()
"""),

    new_code_cell("""\
# 🎯 Target & Feature Selection
print("\\n📌 Columns:", df.columns.tolist())

# Adjust these if column names are different
target_column = 'Price'
feature_columns = ['Area', 'Bedrooms', 'Bathrooms', 'Location']

# One-hot encode categorical variables
df = pd.get_dummies(df, columns=['Location'], drop_first=True)

X = df.drop(target_column, axis=1)
y = df[target_column]
"""),

    new_code_cell("""\
# 🔀 Train-Test Split
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)
"""),

    new_code_cell("""\
# 🔁 Model Training
model = LinearRegression()
model.fit(X_train, y_train)

# 🔮 Prediction
y_pred = model.predict(X_test)
"""),

    new_code_cell("""\
# 📈 Evaluation
mae = mean_absolute_error(y_test, y_pred)
rmse = np.sqrt(mean_squared_error(y_test, y_pred))

print("✅ Model Evaluation:")
print(f"MAE: {mae:.2f}")
print(f"RMSE: {rmse:.2f}")
"""),

    new_code_cell("""\
# 📊 Visualization
plt.figure(figsize=(8, 6))
sns.scatterplot(x=y_test, y=y_pred)
plt.xlabel("Actual Prices")
plt.ylabel("Predicted Prices")
plt.title("Actual vs Predicted House Prices")
plt.grid(True)
plt.show()
""")
]

nb['cells'] = cells

# Save notebook
with open("Task6_House_Price_Prediction.ipynb", "w", encoding="utf-8") as f:
    nbformat.write(nb, f)

print("✅ Notebook created: Task6_House_Price_Prediction.ipynb")
